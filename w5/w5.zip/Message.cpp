#include "Message.h"

namespace w5
{

	bool Message::empty()
	{
		return tweet.empty();
	}
}